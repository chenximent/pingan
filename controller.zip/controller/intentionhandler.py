from __future__ import print_function
import time
import numpy as np
import traceback
from tensorflow_serving.apis import get_model_metadata_pb2
from tensorflow_serving.apis import model_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc
from tensorflow_serving.apis import predict_pb2
import tensorflow as tf
from .MutiClass import tf_serving_grpc_muticlass
def alg(userInput,intentions):
        try:
            ###之前全量意图接口的入参是form-data格
            if userInput is None or len(str(userInput))==0:
                raise Exception("userInput can not be empty")
            else:
                    sim_score, prob = tf_serving_grpc_muticlass("sim",
                                                                "localhost:8500",
                                                                userInput,
                                                                intentions)
                    s = ""
                    for i in range(len(sim_score)):
                        score = 0
                        ###0命中元素  1不命中元素
                        if sim_score[i] == 1:prob[i]=float(1-prob[i])
                        else:prob[i]=float(prob[i])
                    data={}
                    max={}
                    mscore=0.0
                    data["topn_intention"]=[]
                    for index, item in enumerate(prob):
                            d={}
                            d["intention"]=intentions[index]
                            d["score"]=str(prob[index])
                            data["topn_intention"].append(d)

                            if prob[index] >= mscore:
                                mscore=prob[index]
                                max=d
                    data["top1_intention"]=max
                    return data

        except Exception as e:
            ##logger.error(e)
            traceback.format_exc()
        return None