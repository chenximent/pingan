from intentionhandler import alg

print(alg("你好呀",["打招呼"]))